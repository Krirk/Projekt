Sve:
F�r att installera programmet s� m�ste du anv�nda
setup.exe. Denna fien finns i "Download" mappen. 
Om filen hindras av din brandv�gg, tryck
p� "Installera" f�r att installera programmet.
Du kommer sedan att f� en genv�g f�r programmet p�
ditt skrivbord. Om du inte vill installera programmet s� 
finns det en version som inte beh�vs installeras. I 
Executional finner du "Kalk(Projekt).exe". K�r denna 
filen s� �ppnas programmet. Denna filen kan du plasera 
var du �n vill i din dator.


Eng:
To install the program, you must use setup.exe. This file
is found in the "Download" map. If the file is hindered by 
your firewall, you will need to click "Install" to install the
program. You will then get a shortcut of the program on 
your desktop. If you don't wish to download the program
but still use it then there is a executional version that does 
not require that you download the program in the 
"Executional" map. This file can be placed where ever you 
wish.